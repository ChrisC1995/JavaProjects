package Calc;

import java.io.IOException;

/**
 * Created by christiancampbell on 10/10/16.
 */
public class Main {
    public static void main(String[] args)throws IOException{
    Calc.Calculator();
    }
}
